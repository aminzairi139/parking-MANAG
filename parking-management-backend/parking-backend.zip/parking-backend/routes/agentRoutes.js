﻿const express = require("express");
const router = express.Router();
const auth = require("../middleware/auth");
const role = require("../middleware/role");
const agentController = require("../controllers/agentController");

router.get("/search/:plate", auth, role(["agent"]), agentController.searchByPlate);
router.post("/notify", auth, role(["agent"]), agentController.sendSmsNotification);
router.post("/penalty", auth, role(["agent"]), agentController.createPenalty);

module.exports = router;
