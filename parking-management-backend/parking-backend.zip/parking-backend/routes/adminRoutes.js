﻿const express = require("express");
const router = express.Router();
const auth = require("../middleware/auth");
const role = require("../middleware/role");
const adminController = require("../controllers/adminController");

router.post("/agents", auth, role(["admin"]), adminController.createAgent);
router.get("/agents", auth, role(["admin"]), adminController.getAgents);
router.get("/agents/:id", auth, role(["admin"]), adminController.getAgent);
router.put("/agents/:id", auth, role(["admin"]), adminController.updateAgent);
router.delete("/agents/:id", auth, role(["admin"]), adminController.deleteAgent);
router.post("/parkings/:id/approve", auth, role(["admin"]), adminController.approveParking);

module.exports = router;
