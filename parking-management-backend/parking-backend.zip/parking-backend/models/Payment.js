﻿const mongoose = require("mongoose");

const paymentSchema = new mongoose.Schema(
  {
    reservation: { type: mongoose.Schema.Types.ObjectId, ref: "Reservation", required: true },
    user: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true },
    amount: { type: Number, required: true },
    method: { type: String, enum: ["D17", "card"], default: "D17" },
    status: { type: String, enum: ["created", "confirmed", "failed"], default: "created" },
    transactionId: { type: String },
  },
  { timestamps: true },
);

module.exports = mongoose.model("Payment", paymentSchema);
