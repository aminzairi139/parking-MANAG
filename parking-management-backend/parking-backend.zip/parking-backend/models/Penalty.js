﻿const mongoose = require("mongoose");

const penaltySchema = new mongoose.Schema(
  {
    user: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true },
    plateNumber: { type: String, required: true, trim: true },
    amount: { type: Number, required: true },
    reason: { type: String, required: true },
    paid: { type: Boolean, default: false },
  },
  { timestamps: true },
);

module.exports = mongoose.model("Penalty", penaltySchema);
