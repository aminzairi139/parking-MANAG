﻿const mongoose = require("mongoose");

const reservationSchema = new mongoose.Schema(
  {
    user: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true },
    parking: { type: mongoose.Schema.Types.ObjectId, ref: "Parking", required: true },
    plateNumber: { type: String, required: true, trim: true },
    startTime: { type: Date, required: true },
    endTime: { type: Date, required: true },
    status: { type: String, enum: ["pending", "paid", "cancelled"], default: "pending" },
    amount: { type: Number, required: true },
    qrCode: { type: String },
  },
  { timestamps: true },
);

module.exports = mongoose.model("Reservation", reservationSchema);
