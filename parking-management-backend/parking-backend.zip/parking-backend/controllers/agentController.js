﻿const Reservation = require("../models/Reservation");
const User = require("../models/User");
const Penalty = require("../models/Penalty");
const smsService = require("../services/smsService");

exports.searchByPlate = async (req, res, next) => {
  try {
    const { plate } = req.params;
    const reservations = await Reservation.find({ plateNumber: new RegExp(plate, "i") }).populate("user", "name email phone");
    res.json({ success: true, data: reservations });
  } catch (error) {
    next(error);
  }
};

exports.sendSmsNotification = async (req, res, next) => {
  try {
    const { userId, message } = req.body;
    const user = await User.findById(userId);
    if (!user || !user.phone) {
      return res.status(404).json({ success: false, message: "User phone not found" });
    }
    await smsService.sendSms(user.phone, message || "Votre parking est prêt");
    res.json({ success: true, message: "SMS envoyé" });
  } catch (error) {
    next(error);
  }
};

exports.createPenalty = async (req, res, next) => {
  try {
    const { userId, plateNumber, amount, reason } = req.body;
    const user = await User.findById(userId);
    if (!user) {
      return res.status(404).json({ success: false, message: "Utilisateur non trouvé" });
    }
    const penalty = await Penalty.create({ user: user._id, plateNumber, amount, reason });
    res.status(201).json({ success: true, data: penalty });
  } catch (error) {
    next(error);
  }
};
