﻿const Reservation = require("../models/Reservation");
const Parking = require("../models/Parking");
const paymentService = require("../services/paymentService");

exports.createReservation = async (req, res, next) => {
  try {
    const { parkingId, plateNumber, startTime, endTime, amount } = req.body;
    const parking = await Parking.findById(parkingId);
    if (!parking || !parking.approved) {
      return res.status(400).json({ success: false, message: "Parking not available" });
    }
    const reservation = await Reservation.create({
      user: req.user._id,
      parking: parking._id,
      plateNumber,
      startTime,
      endTime,
      amount,
      status: "pending",
    });
    res.status(201).json({ success: true, data: reservation });
  } catch (error) {
    next(error);
  }
};

exports.payReservation = async (req, res, next) => {
  try {
    const { reservationId, paymentMethod } = req.body;
    const reservation = await Reservation.findOne({ _id: reservationId, user: req.user._id });
    if (!reservation) {
      return res.status(404).json({ success: false, message: "Reservation not found" });
    }
    const payment = await paymentService.processPayment(reservation, paymentMethod || "D17");
    if (payment.status !== "confirmed") {
      return res.status(400).json({ success: false, message: "Payment failed" });
    }
    reservation.status = "paid";
    reservation.qrCode = payment.qrCode;
    await reservation.save();
    res.json({ success: true, data: { reservation, payment } });
  } catch (error) {
    next(error);
  }
};

exports.getReservationQr = async (req, res, next) => {
  try {
    const reservation = await Reservation.findOne({ _id: req.params.id, user: req.user._id });
    if (!reservation || !reservation.qrCode) {
      return res.status(404).json({ success: false, message: "QR code not found" });
    }
    res.json({ success: true, data: { qrCode: reservation.qrCode } });
  } catch (error) {
    next(error);
  }
};
