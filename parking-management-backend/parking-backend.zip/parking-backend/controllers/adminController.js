﻿const bcrypt = require("bcryptjs");
const User = require("../models/User");
const Parking = require("../models/Parking");

exports.createAgent = async (req, res, next) => {
  try {
    const { name, email, password, phone } = req.body;
    const existing = await User.findOne({ email });
    if (existing) {
      return res.status(400).json({ success: false, message: "Agent already exists" });
    }
    const hashed = await bcrypt.hash(password, 10);
    const agent = await User.create({ name, email, password: hashed, role: "agent", phone });
    res.status(201).json({ success: true, data: agent });
  } catch (error) {
    next(error);
  }
};

exports.getAgents = async (req, res, next) => {
  try {
    const agents = await User.find({ role: "agent" });
    res.json({ success: true, data: agents });
  } catch (error) {
    next(error);
  }
};

exports.getAgent = async (req, res, next) => {
  try {
    const agent = await User.findById(req.params.id);
    if (!agent || agent.role !== "agent") {
      return res.status(404).json({ success: false, message: "Agent not found" });
    }
    res.json({ success: true, data: agent });
  } catch (error) {
    next(error);
  }
};

exports.updateAgent = async (req, res, next) => {
  try {
    const agent = await User.findByIdAndUpdate(req.params.id, req.body, { new: true });
    if (!agent || agent.role !== "agent") {
      return res.status(404).json({ success: false, message: "Agent not found" });
    }
    res.json({ success: true, data: agent });
  } catch (error) {
    next(error);
  }
};

exports.deleteAgent = async (req, res, next) => {
  try {
    const agent = await User.findById(req.params.id);
    if (!agent || agent.role !== "agent") {
      return res.status(404).json({ success: false, message: "Agent not found" });
    }
    await agent.remove();
    res.json({ success: true, message: "Agent deleted" });
  } catch (error) {
    next(error);
  }
};

exports.approveParking = async (req, res, next) => {
  try {
    const parking = await Parking.findById(req.params.id);
    if (!parking) {
      return res.status(404).json({ success: false, message: "Parking not found" });
    }
    parking.approved = true;
    await parking.save();
    res.json({ success: true, data: parking });
  } catch (error) {
    next(error);
  }
};
