﻿const QRCode = require("qrcode");
const Payment = require("../models/Payment");

exports.processPayment = async (reservation, method) => {
  const transactionId = `D17-${Date.now()}-${Math.floor(Math.random() * 10000)}`;
  const qrPayload = `${reservation._id}:${reservation.plateNumber}:${transactionId}`;
  const qrCode = await QRCode.toDataURL(qrPayload);
  const payment = await Payment.create({
    reservation: reservation._id,
    user: reservation.user,
    amount: reservation.amount,
    method,
    status: "confirmed",
    transactionId,
  });
  return { ...payment.toObject(), qrCode };
};
